Imgur Album Downlaoder
======================

A Pure JS webapp to download entire or parts of Imgur albums.

Go to http://dschep.github.io/imgur-album-downloader to use it!

Note: Large albums or albums containing very high resolution photos
might not work, depending on how much RAM your system has. You can
download whole albums natively on Imgur by appending `/zip` to the URL.
